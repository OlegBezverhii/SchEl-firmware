
var config = 
{ 
  logo:         "../images/SchneiderElectric.gif",
  logoPocketPC: "../images/SchneiderElectricPocketPC.gif",
  titleHtml:    "FactoryCast Web Server NOE 771 11",
  title:        "FactoryCast&trade; NOE 771 11",
  titleColor:   "White",
  titleBgColor: "#138F34",
  homeImage:     "../../images/noe77111.jpg",
  homeVersion:   "Web site version : 6.4",
  homeCopyRight: "&copy; 2015 Schneider Electric. All rights reserved."
}

